import React from 'react';
import './Header.css';
function Navbar() {
    return (
        <div className= 'header'>
        <h2>Navbar</h2>
        </div>
    )
}

export default Navbar;