import './App.css';
import Navbar from './components/Navbar/Navbar';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import Home from './components/pages/Home';
import About from './components/pages/About';
import Work from './components/pages/Work';
import Projects from './components/pages/Projects';
import Connect from './components/pages/Connect';


function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <Switch>
          <Route path='/' exact component={Home}></Route>
          <Route path='/about' exact component={About}></Route>
          <Route path='/work' exact component={Work}></Route>
          <Route path='/projects' exact component={Projects}></Route>
          <Route path='/connect' exact component={Connect}></Route>



        </Switch>
     </Router>
    </div>
  );
}

export default App;
