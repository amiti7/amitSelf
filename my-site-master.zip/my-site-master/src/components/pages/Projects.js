import React from 'react';

export default function Projects() {
    return (
        <>
        <h1 className='projects'>List of all projects</h1>
        </>
    )
}