import React from 'react';

export default function Work() {
    return (
        <>
        <h1 className='work'>This is Work Page</h1>
        </>
    )
}